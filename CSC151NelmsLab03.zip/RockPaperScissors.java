////////////////////////////////////////////////////////////////////////////////
//  Course:   CSC 151 Spring 2021
//  Section:  (0002)
// 
//  Project:  NelmsLesson03
//  File:     RockPaperScissors.java
//  
//  Name:     Kristen Nelms
//  Email:    klnelms@my.waketech.edu
////////////////////////////////////////////////////////////////////////////////

/**
 * Write a program that plays the popular scissor�rock�paper game. (A scissor can cut a paper, a rock can knock a scissor, and a paper can wrap a rock.)
 * The program randomly generates a number  0,  1, or  2 representing scissor, rock, and paper. 
 * The program prompts the user to enter a number  0,  1, or  2 and displays a message indicating whether the user or the computer wins, loses, or draws.
 *
 * <p/> Bugs: (Couldn't implement any code to check whether or not user input was correct; wanted to use a for OR while statement or maybe change things up and implement continue and break statements 
 * w/n loops-or maybe elect to practice more with switch statements + break statements when i revisit this?? Either way, all attempts resulted in ONLY output of opponent's move line WITHOUT generating output whether or not user won, tied, or lost)
 * 
 * @author Kristen Nelms
 *
 */

import java.util.Scanner; 

public class RockPaperScissors
{

	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);		 
				
		System.out.print("Enter a number 0 to denote scissors, 1 to denote rock, or 2 to denote paper. ");
		int yourTurn = input.nextInt(); // user inputs their own move
		
		int computerTurn = (int)(Math.random()*3); // random number generator between 0 and 2
			System.out.println("Opponent's move: " + computerTurn); // statement to display randomly generated computer move
					
		// output in the event of a tie
		if (yourTurn == computerTurn) {	
			System.out.println("You tied.");
		}		
		
		// winning output examples for human player: rock vs scissors; scissors vs paper; paper vs rock
		else if ((yourTurn == 1 && computerTurn == 0) || (yourTurn == 0 && computerTurn == 2) || (yourTurn == 2 && computerTurn == 1)) {
			System.out.print("You won.");
		}
		
		else {
			System.out.print("You lost."); //output to demonstrate a loss via all other outcomes
		}
		
	}
}
