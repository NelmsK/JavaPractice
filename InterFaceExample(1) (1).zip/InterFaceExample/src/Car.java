public class Car implements IDrawableObject, IMoveableObject, Cloneable,
	Comparable<Car>
	{
	private int weight;
	

	public Car() {
	}

	public Car(int weight) {
		this.weight = weight;
	}

	// Do the car specific logic here
	public void move() {
		System.out.println("Move the Car");

	}

	public void draw() {
		System.out.println("Draw the Car");
	}
	public Object clone() throws CloneNotSupportedException {
		return (Car)super.clone();
	}

    @Override
    public int compareTo(Car other) {
        if (this.weight < other.weight) {
            return -1;
        }
        if (this.weight == other.weight) {
            return 0;
        }
        return 1;
    }
	
}
