
public interface IDrawableObject {
	void draw();
}
