
public interface IMoveableObject {
	void move();
}
