
public final class InterfaceMain {

	public static void main(String[] args)  {
		Car car = new Car();
		car.move();
		car.draw();
		
		Car carClone = new Car();
		try {
			carClone = (Car) car.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		} 
		carClone.move();
		
		Car car1 = new Car(10);
		Car car2 = new Car(5);
		Car car3 = new Car(44);
		Car car4 = new Car(2);
		Car[] c = {car1,car2,car3,car4};
		
		java.util.Arrays.sort(c);
	}

}
