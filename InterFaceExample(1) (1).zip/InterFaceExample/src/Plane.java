class Plane implements IDrawableObject, IMoveableObject{
 
    public void move(){
    	System.out.println("Move the plane");
    }
 
    public void draw(){
    	System.out.println("Draw the plane");
    }
}