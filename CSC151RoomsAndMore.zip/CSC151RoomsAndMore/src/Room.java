////////////////////////////////////////////////////////////////////////////////
//  Course:   CSC 151 Spring 2021
//  Section:  (0002)
// 
//  Project:  CSC151RoomsAndMore
//  File:     Room.java
//  
//  Name:     (Kristen Nelms)
//  Email:    (klnelms@my.waketech.edu)
////////////////////////////////////////////////////////////////////////////////

/**
 * (Program to calculate the total capacity of a room based on a given area.)
 *
 * <p/> Bugs: (List any known issues or unimplemented features here)
 * 
 * @author (Kristen Nelms)
 *
 */
public class Room //superclass
{
	private int area; //instance variable for area (sqft) of room

	//constructor: takes area of room as parameter
    public Room(int area){
        this.area = area; //using this keyword to reference the data field area of the object being constructed 
    }

    //accessor: returns the area of the room
    public int getSquareFeet(){
        return this.area;
    }
    
    //mutator: sets the square feet of the room
    public void setSquareFeet(int area) {
    	this.area = area;
    }

    // accessor: returns the capacity of room by dividing sqft by 9
    public int getCapacity(){
        return (this.area/9); //int division to produce WHOLE numbers ONLY
    }

    // accessor: returns the sqft and capacity of room
    //toString() method returns a string representation of the object 
    public String toString(){
        return "Area: " + getSquareFeet() + " sqft\tCapacity: " + getCapacity() + " people \n";
    }
}
