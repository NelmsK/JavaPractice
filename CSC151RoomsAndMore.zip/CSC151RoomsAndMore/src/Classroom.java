////////////////////////////////////////////////////////////////////////////////
//  Course:   CSC 151 Spring 2021
//  Section:  (0002)
// 
//  Project:  CSC151RoomsAndMore
//  File:     Classroom.java
//  
//  Name:     (Kristen Nelms)
//  Email:    (klnelms@my.waketech.edu)
////////////////////////////////////////////////////////////////////////////////

/**
 * (This program extends the previous Room class. This program takes various parameters such as the number of chairs and the classroom's area to return the classroom's square feet, capacity, and number of chairs.
 * Note: Program contains an override to set the capacity of the classroom to the number of chairs regardless. )
 *
 * <p/> Bugs: (List any known issues or unimplemented features here)
 * 
 * @author (Kristen Nelms)
 *
 */
public class Classroom extends Room //subclass
{
	private int chairs; //instance variable for # chairs in classroom 

	// constructor: takes area of classroom as parameter 
    public Classroom(int area){
        super(area);
    }

    // constructor: takes area of classroom and number of chairs as parameters
    public Classroom(int area, int chairs){
        super(area);
        this.chairs = chairs;
    }
    //setter: set # of chairs
    public void setChairs(int chairs){
        this.chairs = chairs;
    }
    //getter: return # of chairs
    public int getChairs(){
        return this.chairs;
    }
    
    @Override //override; capacity of classroom = # of chairs
    public int getCapacity(){
        return this.chairs;
    }
    
    //accessor: returns the sqft and capacity of the room as well as the number of chairs 
    @Override
    public String toString(){
    	return "Classroom:\n" + super.toString() + " Number of Chairs: " + getChairs() + "\n"; //method overriding
    }
}
