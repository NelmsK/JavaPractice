////////////////////////////////////////////////////////////////////////////////
//  Course:   CSC 151 Spring 2021
//  Section:  (0002)
// 
//  Project:  CSC151RoomsAndMore
//  File:     Building.java
//  
//  Name:     (Kristen Nelms)
//  Email:    (klnelms@my.waketech.edu)
////////////////////////////////////////////////////////////////////////////////

/**
 * (User creates an array (via while loop) to store various elements containing various room elements--creating classrooms, deciding number
 *  of chairs contained w/n classroom, sqft of room, number of floors within building, etc )
 *
 * <p/> Bugs: (List any known issues or unimplemented features here)
 * 
 * @author (Kristen Nelms)
 *
 */

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Building
{
	public static void main(String[] args) {
		
		Scanner kybd = new Scanner(System.in);		
		ArrayList<Room> list = new ArrayList<Room>(); // declare an ArrayList containing Room elements; beneficial to store an unlimited number of objects 
													//vs traditional fixed array
		Random rand = new Random();

		System.out.println("Enter \n\t1: create classroom\n\t2: create elevator" + "\n\t3: exit");
		int inp = kybd.nextInt();
		while (inp != 3) {
			if (inp == 1) {
				System.out.println("How many chairs? ");
				int ch = kybd.nextInt();
				Room current = new Classroom(rand.nextInt(1000) + 100, ch); //randomly generates classroom area (100-999) and takes user chair input to later store in list
				list.add(current); // add current to the ArrayList
			} else if (inp == 2) {
				Elevator current = new Elevator(rand.nextInt(100) + 10); //randomly generates number for area (10-99)
				if (rand.nextInt(2) == 0) { //randomly generates number 0-1; if generates 0, then... 
					current.up(rand.nextInt(10)); //randomly ascends elevator anywhere from 0-9 flights
				} else {
					current.down(rand.nextInt(10)); //randomly descends elevator anywhere from 0-9 flights
				}				
				list.add(current); // add current to the ArrayList
			}
			System.out.println("Enter \n\t1: create classroom\n\t2: create elevator" + "\n\t3: exit");
			inp = kybd.nextInt();
		}
		kybd.close();
		// create a for loop to walk through the ArrayList its elements, one per line
		for (Room room : list) {
            System.out.println(room);		
	}
		if (list.size() > 0) {			
			//Testing Room: getSquareFeet(), setSquareFeet(1000)  
			list.get(0).setSquareFeet(1000); //setting square footage to 1000 for first room 
			System.out.println("\nTesting using .getSquareFeet() and setSquareFeet(1000) to convert the area of the first room: " + list.get(0).getSquareFeet());
			
			//Testing Classroom: setChairs(), getChairs(), and public Classroom(int area)
			Classroom tempClassroom = new Classroom(2000); 
			System.out.println("\nTesting following methods from Classroom class: setChairs(), getChairs(), and sqft constructor method "); 
			System.out.println("\nTemporary room's chair count BEFORE altering setChairs count: " + tempClassroom.getChairs());
			tempClassroom.setChairs(42); //setting no. of chairs to 42
			System.out.println("AFTER altering the number of chairs to 42: " + tempClassroom.getChairs()); 		
			
			//Testing Elevator: getFloor(), up(16), and down(8)
			Elevator tempElevator = new Elevator(100); 
			System.out.println("\n Testing the following methods from the Elevator class: getFloor(), up, and down ");
			System.out.println("Elevator's floor BEFORE conducting test: " + tempElevator.getFloor());
			tempElevator.up(16); //moving up 16 floors
			tempElevator.down(8); //descending 8 floors 
			System.out.println("Elevator's current floor after executing up(16) and down(8): " + tempElevator.getFloor());
			
		}

	
}
	
}