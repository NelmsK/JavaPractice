////////////////////////////////////////////////////////////////////////////////
//  Course:   CSC 151 Spring 2021
//  Section:  (0002)
// 
//  Project:  CSC151RoomsAndMore
//  File:     Elevator.java
//  
//  Name:     (Kristen Nelms)
//  Email:    (klnelms@my.waketech.edu)
////////////////////////////////////////////////////////////////////////////////

/**
 * (This class also extends from the Room class. The elevator class's purpose is to relay the elevator's: current position (floor), area, capacity, and
 *   the *new* location of the elevator if it has been moved up or down. )
 *
 * <p/> Bugs: (List any known issues or unimplemented features here)
 * 
 * @author (Kristen Nelms)
 *
 */
public class Elevator extends Room //subclass
{
	private int floors = 1; //instance variable for the current floor of the elevator 

	//constructor: takes the area of the elevator as a parameter
    public Elevator(int area){
        super(area); //explicitly invoking superclass's constructor (as they're NOT heritable) 
    }
    // getter for floor 
    public int getFloor() {
    	return this.floors; 
    }
    
    //mutator: increases the current floor by a given parameter 
    public void up(int floors){
        this.floors += floors;
    }
  //mutator: decreases the current floor by a given parameter
    public void down(int floors){
        this.floors -= floors;
    }

    //accessor: returns the square feet and capacity of the elevator, as well as its current floor.
    @Override
    public String toString(){
    	return "Elevator:\n" + super.toString() + "Current Floor: " + this.floors + "\n"; //method overriding
    }
}
